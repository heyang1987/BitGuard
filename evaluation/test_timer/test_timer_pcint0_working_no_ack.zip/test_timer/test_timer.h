/*
 * test_timer.h
 *
 * Created: 3/21/2013 7:05:07 PM
 *  Author: jonas
 */ 


#ifndef TEST_TIMER_H_
#define TEST_TIMER_H_

typedef struct{
	uint8_t start;
	uint8_t middle;
	uint8_t end;
} test_struct_t ;



#endif /* TEST_TIMER_H_ */