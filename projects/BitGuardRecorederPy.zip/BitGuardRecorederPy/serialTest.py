'''
Created on Dec 9, 2013

@author: yang
'''
import serial
import os
#myfile = "result1.txt"
#myfile = "result2.txt"
myfile = "result3.txt"

if os.path.isfile(myfile):
        os.remove(myfile)
# configure the serial connections (the parameters differs on the device you are connecting to)
ser = serial.Serial(
    #port='COM3',
    port='/dev/ttyUSB0',
    baudrate=115200,
    bytesize=serial.EIGHTBITS,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
)

ser.close()
if(not ser.isOpen()):
    ser.open()

f=open(myfile,'w+')

# start data collection
#t=1
while(1):
    data_raw = ser.readline().rstrip() # read data from serial port and strip line endings
    if( len(data_raw.encode('hex')) == 4 ):
        data = str(4351-int(data_raw.encode('hex'),16))
        print data
        f.write(data+"\n")
    #t = t+1
f.close()