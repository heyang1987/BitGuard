'''
Created on Dec 10, 2013

@author: yang
'''
import matplotlib.pyplot as plt
f1 = open("result1.txt","r")      # optimal scheduler
f2 = open("result2.txt","r")      # optimal scheduler
f3 = open("result3.txt","r")      # optimal scheduler
i=1
y1 = []
y2 = []
y3 = []
while(i<=10000):
    line1 = f1.readline().rstrip()
    line2 = f2.readline().rstrip()
    line3 = f3.readline().rstrip()
    y1.append(line1)
    y2.append(line2)
    y3.append(line3)
    i = i+1
#y = s1.split("\n")
x = 1
t = []
while(x <= len(y3)):
    t.append(x)
    x = x + 1
plt.plot(t,y1,'r',label = 'fibonacci')
plt.plot(t,y2,'g',label = 'double function calls')
plt.plot(t,y3,'b',label = 'delay')
plt.axis([0,len(t),0,150])
plt.xlabel("time (us)")
plt.ylabel("Stack size (Bytes)")
plt.legend(loc='lower right')
plt.savefig("stacksize_usage.pdf",bbox_inches=0,format='pdf')
plt.show()